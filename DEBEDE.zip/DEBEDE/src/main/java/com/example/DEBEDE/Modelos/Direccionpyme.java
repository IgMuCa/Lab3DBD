package com.example.DEBEDE.Modelos;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="direccionpyme")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Direccionpyme {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    private int id;
    private int pymeid;
    private String ciudad;
    private String comuna;
    private String calle;
    private String numero;
    private String depto;


}
