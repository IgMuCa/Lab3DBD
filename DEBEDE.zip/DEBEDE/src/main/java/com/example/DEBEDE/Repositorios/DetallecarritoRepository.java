package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Detallecarrito;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;


public interface DetallecarritoRepository extends JpaRepository<Detallecarrito, Integer> {

    @Query("SELECT SUM(dc.totalparcial) " +
            "FROM Detallecarrito dc " +
            "WHERE dc.carritoid = :carritoid AND dc.estadopago = 'no_pagado'")
    Float findTotalByCarritoid(@Param("carritoid") int carritoid);


    @Query("SELECT p.nombre FROM Producto p " +
            "JOIN Detallecarrito dc ON dc.productoid = p.id " +
            "WHERE dc.estadopago = 'pagado' GROUP BY p.nombre " +
            "ORDER BY SUM (dc.totalparcial) DESC " +
            "lIMIT 3")
    List<String> findProductoByVenta();


    @Query("SELECT p.nombre FROM Producto p " +
            "JOIN Detallecarrito dc ON dc.productoid = p.id " +
            "JOIN Producto_pyme pp ON pp.productoid = p.id " +
            "JOIN Pyme py ON py.id = pp.productoid " +
            "WHERE dc.estadopago = 'pagado' AND py.nombre = :empresa " +
            "GROUP BY p.nombre " +
            "ORDER BY SUM (dc.totalparcial) DESC " +
            "lIMIT 3")
    List<String> findProductoByVentaByPyme(@Param("empresa") String empresa);



}