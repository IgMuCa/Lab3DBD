package com.example.DEBEDE.Modelos;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Entity
@Table(name="boleta")
@Data
public class Boleta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    private int id;
    private int carritoid;
    private String tipopago;
    private Date fecha;
    private Double total;

    public Boleta(int id, int carritoid, String tipopago, Date fecha) {
        this.id = id;
        this.carritoid = carritoid;
        this.tipopago = tipopago;
        this.fecha = fecha;
    }

    public Boleta() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipopago() {
        return tipopago;
    }

    public void setTipopago(String tipopago) {
        this.tipopago = tipopago;
    }

    public int getCarritoid() {
        return carritoid;
    }

    public void setCarritoid(int carritoid) {
        this.carritoid = carritoid;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    //Fin de la clase
}


