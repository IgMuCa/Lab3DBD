package com.example.DEBEDE.Servicios;

import com.example.DEBEDE.Modelos.Cliente;
import com.example.DEBEDE.Repositorios.ClienteImplementacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/clientes")
public class ClienteController {
    private final ClienteImplementacion clienteImplementacion;

    @Autowired
    public ClienteController(ClienteImplementacion clienteImplementacion){
        this.clienteImplementacion=clienteImplementacion;}

    //Obtiene todos los clientes
    @GetMapping
    public List<Cliente> listarClientesImp(){
        return clienteImplementacion.listarClientes();
    }

    //Crea un cliente
    @PostMapping
    public Cliente crearClienteImp (@RequestBody Cliente cliente){
        return clienteImplementacion.guardarCliente(cliente);}

    //Actualiza un cliente
    @PutMapping("/{id}")
    public ResponseEntity<Cliente> updateCliente(@PathVariable int id, @RequestBody Cliente cliente) {
        return ResponseEntity.ok(clienteImplementacion.actualizarCliente(id, cliente));
    }

    //Elimina un cliente por id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteClienteImp(@PathVariable int id) {
        clienteImplementacion.eliminarCliente(id);
        return ResponseEntity.noContent().build();
    }

}
