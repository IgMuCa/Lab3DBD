package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Direccioncarrito;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DireccioncarritoRepository extends JpaRepository<Direccioncarrito, Integer> {
}
