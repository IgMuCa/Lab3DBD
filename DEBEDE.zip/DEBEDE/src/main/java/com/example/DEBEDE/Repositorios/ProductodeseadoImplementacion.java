package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Productodeseado;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class ProductodeseadoImplementacion {
    private final ProductodeseadoRepository productodeseadoRepository;
    @Autowired
    public ProductodeseadoImplementacion(ProductodeseadoRepository productodeseadoRepository){
        this.productodeseadoRepository=productodeseadoRepository;}

    //Método que lee todos los productos deseados
    public List<Productodeseado> listarProductodeseados(){
        return this.productodeseadoRepository.findAll();}

    //Método que lee un producto deseado dado un id
    public void obtenerAdministrador(int id) {
        productodeseadoRepository.findById(id);}

   //Método que crea y guarda un producto deseado
    public Productodeseado guardarProductodeseado (Productodeseado productodeseado){
        return productodeseadoRepository.save(productodeseado);}

    //Método eliminar un producto deseado por id
    public void eliminarProductodeseado(int id){
        productodeseadoRepository.deleteById(id);}

    //Metodo para actualizar un producto deseado
    public Productodeseado actualizarProdutodeseado(int id, Productodeseado updateProductodeseado) {
        Optional<Productodeseado> productodeseadoOptional = productodeseadoRepository.findById(id);
        if (productodeseadoOptional.isPresent()) {
            Productodeseado productodeseado = productodeseadoOptional.get();
            productodeseado.setProducto(updateProductodeseado.getProducto());
            productodeseado.setDescripcion(updateProductodeseado.getDescripcion());
            return productodeseadoRepository.save(productodeseado);
        } else {
            throw new RuntimeException("User not found with id " + id);
        }
    }

    //Finalizan los metodos
}
