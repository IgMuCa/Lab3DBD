package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Pyme;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;


public interface PymeRepository extends JpaRepository<Pyme, Integer> {

    @Query("SELECT p " +
            "FROM Pyme p " +
            "JOIN Direccionpyme dp ON p.id = dp.pymeid " +
            "WHERE dp.ciudad = :ciudad")
    List<Pyme> findNombresByCiudad(@Param("ciudad") String ciudad);


    @Modifying
    @Transactional
    @Query("DELETE FROM Direccionpyme d WHERE d.pymeid = :id")
    void eraseDireccionpymeByPymeid(@Param("id") int id);
}
