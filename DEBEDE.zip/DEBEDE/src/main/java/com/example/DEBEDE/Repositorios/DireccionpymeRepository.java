package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Direccionpyme;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DireccionpymeRepository extends JpaRepository<Direccionpyme, Integer> {
}
