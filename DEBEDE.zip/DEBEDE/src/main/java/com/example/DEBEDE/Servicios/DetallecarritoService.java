package com.example.DEBEDE.Servicios;

import com.example.DEBEDE.Modelos.Detallecarrito;
import com.example.DEBEDE.Repositorios.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DetallecarritoService {
    @Autowired
    private final ProductoRepository productoRepository;

    public DetallecarritoService(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    public Detallecarrito calcularTotalParcial(Detallecarrito detallecarrito) {
        // Lógica para calcular el total parcial basado en el producto y la cantidad
        int productoid = detallecarrito.getProductoid();
        int cantidad = detallecarrito.getCantidad();
        int stock = productoRepository.findStockByProductoid(productoid);

        Float precio;
        if (stock >= cantidad) {
            // Obtener el precio del producto
            precio = productoRepository.findById(productoid)
                    .map(producto -> producto.getPrecio())
                    .orElse(0.0f);
        } else {
            precio = (float) 0;
        }
        // Calcular el total parcial
        detallecarrito.setTotalparcial((double) (precio * cantidad));

        return detallecarrito;
    }

}
