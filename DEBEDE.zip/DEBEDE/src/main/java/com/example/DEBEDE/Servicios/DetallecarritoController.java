package com.example.DEBEDE.Servicios;

import com.example.DEBEDE.Modelos.Detallecarrito;
import com.example.DEBEDE.Repositorios.DetallecarritoImplementacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/detallecarrito")
public class DetallecarritoController {
    private final DetallecarritoImplementacion detallecarritoImplementacion;

    @Autowired
    private DetallecarritoService detallecarritoService;

    @Autowired
    public DetallecarritoController(DetallecarritoImplementacion detallecarritoImplementacion){
        this.detallecarritoImplementacion=detallecarritoImplementacion;}

    //Obtiene todos los detalle de carrito
    @GetMapping
    public List<Detallecarrito> listarDetallecarritoImp(){
        return detallecarritoImplementacion.listarDetallecarrito();}


    //Crea un carrito
    @PostMapping
    public ResponseEntity<Detallecarrito> createDetallecarrito(@RequestBody Detallecarrito detallecarrito) {
        detallecarrito = detallecarritoService.calcularTotalParcial(detallecarrito);
        Detallecarrito savedDetallecarrito = detallecarritoImplementacion.guardarDetallecarrito(detallecarrito);
        return ResponseEntity.ok(savedDetallecarrito);
    }

    //Ordena por ventas
    @GetMapping("/ventas")
    public List<String> listarProductosPorVenta(){
        return detallecarritoImplementacion.listarProductosPorVenta();}


    //Ordena por ventas y pyme
    @GetMapping("/ventas/{empresa}")
    public List<String> listarProductosPorVentaPorPyme(String empresa){
        return detallecarritoImplementacion.listarProductosPorVentaPorPyme(empresa);}
}
