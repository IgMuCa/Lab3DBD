package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Carrito;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CarritoRepository extends JpaRepository<Carrito, Integer> {


}
