package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Direccioncarrito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class DireccioncarritoImplementacion {
    private final DireccioncarritoRepository direccioncarritoRepository;
    @Autowired
    public DireccioncarritoImplementacion(DireccioncarritoRepository direccioncarritoRepository){
        this.direccioncarritoRepository=direccioncarritoRepository;}

    //Método que lee todos las direccionecarrito
    public List<Direccioncarrito> listarDireccionescarrito(){
        return this.direccioncarritoRepository.findAll();}

    //Método que lee una direccioncarrito dado un id
    public void obtenerDireccioncarrito(int id) {
        direccioncarritoRepository.findById(id);}

   //Método que crea y guarda una direccioncarrito
    public Direccioncarrito guardarDireccioncarrito (Direccioncarrito direccioncarrito){
        return direccioncarritoRepository.save(direccioncarrito);}

    //Método eliminar una direccioncarrito por id
    public void eliminarDireccioncarrito(int id){
        direccioncarritoRepository.deleteById(id);}

    //Metodo para actualizar una direccioncarrito
    public Direccioncarrito actualizarDireccioncarrito(int id, Direccioncarrito updateDireccioncarrito) {
        Optional<Direccioncarrito> direccioncarritoOptional = direccioncarritoRepository.findById(id);
        if (direccioncarritoOptional.isPresent()) {
            Direccioncarrito direccioncarrito = direccioncarritoOptional.get();
            direccioncarrito.setCarritoid(updateDireccioncarrito.getCarritoid());
            direccioncarrito.setCiudad(updateDireccioncarrito.getCiudad());
            direccioncarrito.setComuna(updateDireccioncarrito.getComuna());
            direccioncarrito.setCalle(updateDireccioncarrito.getCalle());
            direccioncarrito.setNumero(updateDireccioncarrito.getNumero());
            direccioncarrito.setDepto(updateDireccioncarrito.getDepto());
            return direccioncarritoRepository.save(direccioncarrito);
        } else {
            throw new RuntimeException("User not found with id " + id);
        }
    }

    //Finalizan los metodos
}
