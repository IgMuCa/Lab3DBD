package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Boleta;
import org.springframework.data.jpa.repository.JpaRepository;


public interface BoletaRepository extends JpaRepository<Boleta, Integer> {


}
