package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Valoracionusuario;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ValoracionusuarioRepository extends JpaRepository<Valoracionusuario, Integer> {
}
