package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Productodeseado_cliente;
import org.springframework.data.jpa.repository.JpaRepository;


public interface Productodeseado_clienteRepository extends JpaRepository<Productodeseado_cliente, Integer> {
}
