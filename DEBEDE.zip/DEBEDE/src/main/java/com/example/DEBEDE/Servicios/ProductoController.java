package com.example.DEBEDE.Servicios;

import com.example.DEBEDE.Modelos.Producto;
import com.example.DEBEDE.Repositorios.ProductoImplementacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/productos")
public class ProductoController {
    private final ProductoImplementacion productoImplementacion;

    @Autowired
    public ProductoController(ProductoImplementacion productoImplementacion){
        this.productoImplementacion = productoImplementacion;}

    //Obtiene todos los productos
    @GetMapping
    public List<Producto> listarProductoImp(){
        return productoImplementacion.listarProductos();
    }

    //Crea un producto
    @PostMapping
    public Producto crearProductoImp (@RequestBody Producto producto){
        return productoImplementacion.guardarProducto(producto);}

    //Elimina un producto deseado  por id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProductoImp(@PathVariable int id) {
       productoImplementacion.eliminarProducto(id);
        return ResponseEntity.noContent().build();
    }

    //Actualiza un cliente
    @PutMapping("/{id}")
    public ResponseEntity<Producto> updateProducto(@PathVariable int id, @RequestBody Producto producto) {
        return ResponseEntity.ok(productoImplementacion.actualizarProducto(id, producto));
    }

    //Identifica productos por ubicacion
    @GetMapping("/{ciudad}")
    public List<Producto> listarProductosPorCiudad(String ciudad){
        return productoImplementacion.listarProductosPorCiudad(ciudad);}


    //Categoriza producto
    @GetMapping("/categoria/{categoria}")
    public List<Producto> listarProductosPorCategoria(String categoria){
        return productoImplementacion.listarProductosPorCategoria(categoria);}



}
