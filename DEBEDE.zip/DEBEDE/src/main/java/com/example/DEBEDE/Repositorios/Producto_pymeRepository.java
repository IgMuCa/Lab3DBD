package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Producto_pyme;
import org.springframework.data.jpa.repository.JpaRepository;


public interface Producto_pymeRepository extends JpaRepository<Producto_pyme, Integer> {
}
