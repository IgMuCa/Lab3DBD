package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Direccionpyme;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class DireccionpymeImplementacion {
    private final DireccionpymeRepository direccionpymeRepository;
    @Autowired
    public DireccionpymeImplementacion(DireccionpymeRepository direccionpymeRepository){
        this.direccionpymeRepository=direccionpymeRepository;}

    //Método que lee todos las direccionespyme
    public List<Direccionpyme> listarDireccionespyme(){
        return this.direccionpymeRepository.findAll();}

    //Método que lee una direccionpyme dado un id
    public void obtenerDireccionpyme(int id) {
        direccionpymeRepository.findById(id);}

   //Método que crea y guarda una direccionpyme
    public Direccionpyme guardarDireccionpyme (Direccionpyme direccionpyme){
        return direccionpymeRepository.save(direccionpyme);}

    //Método eliminar una direccionpyme por id
    public void eliminarDireccionpyme(int id){
        direccionpymeRepository.deleteById(id);}

    //Metodo para actualizar una direccionpyme
    public Direccionpyme actualizarDireccionpyme(int id, Direccionpyme updateDireccionpyme) {
        Optional<Direccionpyme> direccionpymeOptional = direccionpymeRepository.findById(id);
        if (direccionpymeOptional.isPresent()) {
            Direccionpyme direccionpyme = direccionpymeOptional.get();
            direccionpyme.setPymeid(updateDireccionpyme.getPymeid());
            direccionpyme.setCiudad(updateDireccionpyme.getCiudad());
            direccionpyme.setComuna(updateDireccionpyme.getComuna());
            direccionpyme.setCalle(updateDireccionpyme.getCalle());
            direccionpyme.setNumero(updateDireccionpyme.getNumero());
            direccionpyme.setDepto(updateDireccionpyme.getDepto());
            return direccionpymeRepository.save(direccionpyme);
        } else {
            throw new RuntimeException("User not found with id " + id);
        }
    }

    //Finalizan los metodos
}
