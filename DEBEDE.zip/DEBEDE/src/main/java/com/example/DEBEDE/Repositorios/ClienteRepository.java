package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ClienteRepository extends JpaRepository<Cliente, Integer> {
}
