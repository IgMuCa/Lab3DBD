package com.example.DEBEDE.Servicios;

import com.example.DEBEDE.Modelos.Valoracionusuario;
import com.example.DEBEDE.Repositorios.ValoracionusuarioImplementacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/valoracionusuarios")
public class ValoracionusuarioController {
    private final ValoracionusuarioImplementacion valoracionusuarioImplementacion;

    @Autowired
    public ValoracionusuarioController(ValoracionusuarioImplementacion valoracionusuarioImplementacion){
        this.valoracionusuarioImplementacion=valoracionusuarioImplementacion;}

    //Obtiene todos las valoraciones
    @GetMapping
    public List<Valoracionusuario> listarValoracionusuariosImp(){
        return valoracionusuarioImplementacion.listarValoracionusuario();
    }

    //Crea una valoración
    @PostMapping
    public Valoracionusuario crearValoracionusuarioImp (@RequestBody Valoracionusuario valoracionusuario){
        return valoracionusuarioImplementacion.guardarValoracionusuario(valoracionusuario);}

    //Actualiza una valoracion
    @PutMapping("/{id}")
    public ResponseEntity<Valoracionusuario> updateValoracionusuario(@PathVariable int id, @RequestBody Valoracionusuario valoracionusuario) {
        return ResponseEntity.ok(valoracionusuarioImplementacion.actualizarValoracionusuario(id, valoracionusuario));
    }

    //Elimina una valoracion por id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteValoracionusuarioImp(@PathVariable int id) {
        valoracionusuarioImplementacion.eliminarValoracionusuario(id);
        return ResponseEntity.noContent().build();
    }

}
