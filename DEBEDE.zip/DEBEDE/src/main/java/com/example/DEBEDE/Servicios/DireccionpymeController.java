package com.example.DEBEDE.Servicios;

import com.example.DEBEDE.Modelos.Direccionpyme;
import com.example.DEBEDE.Repositorios.DireccionpymeImplementacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/direccionpyme")
public class DireccionpymeController {
    private final DireccionpymeImplementacion direccionpymeImplementacion;

    @Autowired
    public DireccionpymeController(DireccionpymeImplementacion direccionpymeImplementacion){
        this.direccionpymeImplementacion =direccionpymeImplementacion;}

    //Obtiene todos las direcciones pyme
    @GetMapping
    public List<Direccionpyme> listarDireccionespymeImp(){
        return direccionpymeImplementacion.listarDireccionespyme();
    }

    //Crea una direccionpyme
    @PostMapping
    public Direccionpyme crearDireccionpymeImp (@RequestBody Direccionpyme direccionpyme){
        return direccionpymeImplementacion.guardarDireccionpyme(direccionpyme);}

    //Actualiza una direccionpyme
    @PutMapping("/{id}")
    public ResponseEntity<Direccionpyme> updateDireccionpyme(@PathVariable int id, @RequestBody Direccionpyme direccionpyme) {
        return ResponseEntity.ok(direccionpymeImplementacion.actualizarDireccionpyme(id, direccionpyme));
    }

    //Elimina una direccionpyme por id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDireccionpymeImp(@PathVariable int id) {
        direccionpymeImplementacion.eliminarDireccionpyme(id);
        return ResponseEntity.noContent().build();
    }

}
