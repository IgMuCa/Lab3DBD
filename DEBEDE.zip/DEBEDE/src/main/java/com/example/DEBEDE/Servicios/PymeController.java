package com.example.DEBEDE.Servicios;

import com.example.DEBEDE.Modelos.Pyme;
import com.example.DEBEDE.Repositorios.PymeImplementacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pymes")
public class PymeController {
    private final PymeImplementacion pymeImplementacion;

    @Autowired
    public PymeController(PymeImplementacion pymeImplementacion){
        this.pymeImplementacion=pymeImplementacion;}

    //Obtiene todas las pymes
    @GetMapping
    public List<Pyme> listarPymesImp(){
        return pymeImplementacion.listarPymes();
    }

    //Crea una pyme
    @PostMapping
    public Pyme crearPymeImp (@RequestBody Pyme pyme){
        return pymeImplementacion.guardarPyme(pyme);}

    //Actualiza una pyme
    @PutMapping("/{id}")
    public ResponseEntity<Pyme> updatePyme(@PathVariable int id, @RequestBody Pyme pyme) {
        return ResponseEntity.ok(pymeImplementacion.actualizarPyme(id, pyme));
    }

    //Elimina una pyme por id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePymeImp(@PathVariable int id) {
        pymeImplementacion.eliminarPyme(id);
        return ResponseEntity.noContent().build();
    }

    //Encontrar pyme dada una ciudad
    @GetMapping("/{ciudad}")
    public List<Pyme> PymePorCiudadImp(String ciudad){
        return pymeImplementacion.PymePorCiudad(ciudad);}




}
