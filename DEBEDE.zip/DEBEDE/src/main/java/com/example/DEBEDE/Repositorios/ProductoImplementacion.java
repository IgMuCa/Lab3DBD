package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Producto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class ProductoImplementacion {
    private final ProductoRepository productoRepository;
    @Autowired
    public ProductoImplementacion(ProductoRepository productoRepository){
        this.productoRepository=productoRepository;}

    //Método que lee todas los productos
    public List<Producto> listarProductos(){
        return this.productoRepository.findAll();}

    //Método que lee un producto dado un id
    public void obtenerProducto(int id) {
        productoRepository.findById(id);}
    
   //Método que crea y guarda un producto
    public Producto guardarProducto (Producto producto){
        return productoRepository.save(producto);}

    //Método eliminar un producto por id
    public void eliminarProducto(int id){
        productoRepository.eraseProductopymeByProductoid(id);
        productoRepository.deleteById(id);}

    //Obtener precio producto
    public Double obtenerPrecioProducto(int productoid) {
        return productoRepository.findPrecioByProductoid(productoid) != null ?
                productoRepository.findPrecioByProductoid(productoid).doubleValue() : null;
    }

    //Obtener producto por ubicacion (Ciudad)
    public List<Producto> listarProductosPorCiudad(String ciudad){
        return productoRepository.findProductoByCiudad(ciudad);}


    //Obtener producto por categoría
    public List<Producto> listarProductosPorCategoria(String categoria){
        return productoRepository.findByCategoria(categoria);}

    //Metodo para actualizar un cliente
    public Producto actualizarProducto(int id, Producto updateProducto) {
        Optional<Producto> productoOptional = productoRepository.findById(id);
        if (productoOptional.isPresent()) {
            Producto producto = productoOptional.get();
            producto.setNombre(updateProducto.getNombre());
            producto.setPrecio(updateProducto.getPrecio());
            producto.setStock(updateProducto.getStock());
            producto.setCategoriaid(updateProducto.getCategoriaid());
            producto.setUrl(updateProducto.getUrl());
            return productoRepository.save(producto);
        } else {
            throw new RuntimeException("User not found with id " + id);
        }
    }

 //Finalizan los metodos
}
