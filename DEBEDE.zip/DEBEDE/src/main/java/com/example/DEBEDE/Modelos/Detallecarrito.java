package com.example.DEBEDE.Modelos;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name="detallecarrito")
@Data
public class Detallecarrito {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    private int id;
    private int carritoid;
    private int productoid;
    private int cantidad;
    private String estadopago;
    private Double totalparcial;

    public Detallecarrito(int id, int carritoid, int productoid, int cantidad, String estadopago) {
        this.id = id;
        this.carritoid = carritoid;
        this.productoid = productoid;
        this.cantidad = cantidad;
        this.estadopago = estadopago;
    }

    public Detallecarrito() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCarritoid() {
        return carritoid;
    }

    public void setCarritoid(int carritoid) {
        this.carritoid = carritoid;
    }

    public int getProductoid() {
        return productoid;
    }

    public void setProductoid(int productoid) {
        this.productoid = productoid;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getEstadopago() {
        return estadopago;
    }

    public void setEstadopago(String estadopago) {
        this.estadopago = estadopago;
    }

    public Double getTotalparcial() {
        return totalparcial;
    }

    public void setTotalparcial(Double totalparcial) {
        this.totalparcial = totalparcial;
    }
//Fin de la clase
}


