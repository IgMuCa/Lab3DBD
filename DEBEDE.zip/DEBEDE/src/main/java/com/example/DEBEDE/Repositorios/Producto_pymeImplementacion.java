package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Producto_pyme;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class Producto_pymeImplementacion {
    private final Producto_pymeRepository producto_pymeRepository;
    @Autowired
    public Producto_pymeImplementacion(Producto_pymeRepository producto_pymeRepository){
        this.producto_pymeRepository=producto_pymeRepository;}

    //Método que lee todas los productos_pyme
    public List<Producto_pyme> listarProductos_pyme(){
        return this.producto_pymeRepository.findAll();}

    //Método que lee un producto_pyme dado un id
    public void obtenerProducto_pyme(int id) {
        producto_pymeRepository.findById(id);}
    
   //Método que crea y guarda un producto_pyme
    public Producto_pyme guardarProducto_pyme(Producto_pyme producto_pyme){
        return producto_pymeRepository.save(producto_pyme);}

    //Método eliminar un producto por id
    public void eliminarProducto_pyme(int id){
        producto_pymeRepository.deleteById(id);}

    //Finalizan los metodos
}
