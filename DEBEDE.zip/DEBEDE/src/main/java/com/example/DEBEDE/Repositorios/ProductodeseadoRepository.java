package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Productodeseado;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ProductodeseadoRepository extends JpaRepository<Productodeseado, Integer> {
}
