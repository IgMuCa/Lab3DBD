package com.example.DEBEDE.Modelos;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="productodeseado_cliente")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Productodeseado_cliente {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    private int id;
    private int productodeseadoid;
    private int clienteid;

}
