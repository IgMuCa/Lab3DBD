package com.example.DEBEDE.Servicios;

import com.example.DEBEDE.Modelos.Direccioncarrito;
import com.example.DEBEDE.Repositorios.DireccioncarritoImplementacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/direccioncarrito")
public class DireccioncarritoController {
    private final DireccioncarritoImplementacion direccioncarritoImplementacion;

    @Autowired
    public DireccioncarritoController(DireccioncarritoImplementacion direccioncarritoImplementacion){
        this.direccioncarritoImplementacion=direccioncarritoImplementacion;}

    //Obtiene todos las direcciones carrito
    @GetMapping
    public List<Direccioncarrito> listarDireccionescarritoImp(){
        return direccioncarritoImplementacion.listarDireccionescarrito();
    }

    //Crea una direccioncarrito
    @PostMapping
    public Direccioncarrito crearDireccioncarritoImp (@RequestBody Direccioncarrito direccioncarrito){
        return direccioncarritoImplementacion.guardarDireccioncarrito(direccioncarrito);}

    //Actualiza una direccioncarrito
    @PutMapping("/{id}")
    public ResponseEntity<Direccioncarrito> updateDireccioncarrito(@PathVariable int id, @RequestBody Direccioncarrito direccioncarrito) {
        return ResponseEntity.ok(direccioncarritoImplementacion.actualizarDireccioncarrito(id, direccioncarrito));
    }

    //Elimina una direccioncarrito por id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDireccionpymeImp(@PathVariable int id) {
        direccioncarritoImplementacion.eliminarDireccioncarrito(id);
        return ResponseEntity.noContent().build();
    }

}
