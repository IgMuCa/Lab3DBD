package com.example.DEBEDE.Servicios;

import com.example.DEBEDE.Modelos.Categoria;
import com.example.DEBEDE.Repositorios.CategoriaImplementacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/categorias")
public class CategoriaController {
    private final CategoriaImplementacion categoriaImplementacion;

    @Autowired
    public CategoriaController(CategoriaImplementacion categoriaImplementacion){
        this.categoriaImplementacion=categoriaImplementacion;}

    //Obtiene todos las categoirias
    @GetMapping
    public List<Categoria> listarCategoriasImp(){
        return categoriaImplementacion.listarCategorias();
    }

    //Crea una categoria
    @PostMapping
    public Categoria crearCategoriaImp (@RequestBody Categoria categoria){
        return categoriaImplementacion.guardarCategoria(categoria);}

    //Actualiza una Categoria
    @PutMapping("/{id}")
    public ResponseEntity<Categoria> updateCategoria(@PathVariable int id, @RequestBody Categoria categoria) {
        return ResponseEntity.ok(categoriaImplementacion.actualizarCategoria(id, categoria));
    }

    //Elimina un categoria por id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCategoriaImp(@PathVariable int id) {
        categoriaImplementacion.eliminarCategoria(id);
        return ResponseEntity.noContent().build();
    }

}
