package com.example.DEBEDE.Servicios;

import com.example.DEBEDE.Modelos.Boleta;
import com.example.DEBEDE.Repositorios.BoletaImplementacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/boleta")
public class BoletaController {
    private final BoletaImplementacion boletaImplementacion;

    @Autowired
    private BoletaService boletaService;

    @Autowired
    public BoletaController(BoletaImplementacion boletaImplementacion){
        this.boletaImplementacion= boletaImplementacion;}

    //Obtiene todos las boletas
    @GetMapping
    public List<Boleta> listarBoletasImp(){
        return boletaImplementacion.listarBoletas();}


    //Crea una boleta
    @PostMapping
    public ResponseEntity<Boleta> createBoleta(@RequestBody Boleta boleta) {
        boleta = boletaService.calcularTotal(boleta);
        Boleta savedboleta = boletaImplementacion.guardarBoleta(boleta);
        return ResponseEntity.ok(savedboleta);
    }



}
