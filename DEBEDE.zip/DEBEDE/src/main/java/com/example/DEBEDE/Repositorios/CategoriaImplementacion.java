package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Categoria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class CategoriaImplementacion {
    private final CategoriaRepository categoriaRepository;
    @Autowired
    public CategoriaImplementacion(CategoriaRepository categoriaRepository){
        this.categoriaRepository=categoriaRepository;}

    //Método que lee todos las categorias
    public List<Categoria> listarCategorias(){
        return this.categoriaRepository.findAll();}

    //Método que lee una categoria dado un id
    public void obtenerCategoria(int id) {
        categoriaRepository.findById(id);}

   //Método que crea y guarda una categoria
    public Categoria guardarCategoria (Categoria categoria){
        return categoriaRepository.save(categoria);}

    //Método eliminar una categoria por id
    public void eliminarCategoria(int id){
        categoriaRepository.deleteById(id);}

    //Metodo para actualizar una categoria
    public Categoria actualizarCategoria(int id, Categoria updateCategoria) {
        Optional<Categoria> categoriaOptional = categoriaRepository.findById(id);
        if (categoriaOptional.isPresent()) {
            Categoria categoria = categoriaOptional.get();
            categoria.setCategoriaprod(updateCategoria.getCategoriaprod());
            return categoriaRepository.save(categoria);
        } else {
            throw new RuntimeException("User not found with id " + id);
        }
    }
    //Finalizan los metodos
}
