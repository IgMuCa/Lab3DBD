package com.example.DEBEDE.Modelos;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="producto_pyme")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Producto_pyme {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    private int id;
    private int productoid;
    private int pymeid;

}
