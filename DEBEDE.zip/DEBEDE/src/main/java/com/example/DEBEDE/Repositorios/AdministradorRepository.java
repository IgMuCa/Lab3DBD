package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Administrador;
import org.springframework.data.jpa.repository.JpaRepository;


public interface AdministradorRepository extends JpaRepository<Administrador, Integer> {
}
