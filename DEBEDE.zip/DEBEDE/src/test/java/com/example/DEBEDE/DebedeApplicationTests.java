package com.example.DEBEDE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DebedeApplicationTests {

	@Test
	void contextLoads() {
	}

}
