package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {

}
