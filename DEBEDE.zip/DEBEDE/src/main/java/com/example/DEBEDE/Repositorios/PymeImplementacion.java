package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Pyme;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class PymeImplementacion {
    private final PymeRepository pymeRepository;
    @Autowired
    public PymeImplementacion(PymeRepository pymeRepository){
        this.pymeRepository=pymeRepository;}

    //Método que lee todas las pymes
    public List<Pyme> listarPymes(){
        return this.pymeRepository.findAll();}

    //Método que lee una pyme dado un id
    public void obtenerPyme(int id) {
        pymeRepository.findById(id);}
    
   //Método que crea y guarda un cliente
    public Pyme guardarPyme (Pyme pyme){
        return pymeRepository.save(pyme);}

    //Método eliminar una pyme por id
    public void eliminarPyme(int id){
        pymeRepository.eraseDireccionpymeByPymeid(id);
        pymeRepository.deleteById(id);}

    //Metodo para actualizar una pyme
    public Pyme actualizarPyme(int id, Pyme updatePyme) {
        Optional<Pyme> pymeOptional = pymeRepository.findById(id);
        if (pymeOptional.isPresent()) {
            Pyme pyme = pymeOptional.get();
            pyme.setNombre(updatePyme.getNombre());
            pyme.setContrasena(updatePyme.getContrasena());
            pyme.setEmail(updatePyme.getEmail());
            pyme.setTelefono(updatePyme.getTelefono());
            return pymeRepository.save(pyme);
        } else {
            throw new RuntimeException("User not found with id " + id);
        }
    }

   //Encontrar pyme dada una ciudad
   public List<Pyme> PymePorCiudad(String ciudad){
       return pymeRepository.findNombresByCiudad(ciudad);}



    //Fin de los metodos
}
