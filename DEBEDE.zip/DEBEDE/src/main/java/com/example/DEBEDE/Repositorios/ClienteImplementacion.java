package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Cliente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class ClienteImplementacion {
    private final ClienteRepository clienteRepository;
    @Autowired
    public ClienteImplementacion(ClienteRepository clienteRepository){
        this.clienteRepository=clienteRepository;}

    //Método que lee todos los clientes
    public List<Cliente> listarClientes(){
        return this.clienteRepository.findAll();}

    //Método que lee un cliente dado un id
    public void obtenerCliente(int id){
         clienteRepository.findById(id);}

   //Método que crea y guarda un cliente
    public Cliente guardarCliente (Cliente cliente){
        return clienteRepository.save(cliente);}

    //Método eliminar un cliente por id
    public void eliminarCliente(int id){
        clienteRepository.deleteById(id);}

    //Metodo para actualizar un cliente
    public Cliente actualizarCliente(int id, Cliente updateCliente) {
        Optional<Cliente> clienteOptional = clienteRepository.findById(id);
        if (clienteOptional.isPresent()) {
            Cliente cliente = clienteOptional.get();
            cliente.setNombre(updateCliente.getNombre());
            cliente.setApellido(updateCliente.getApellido());
            cliente.setContrasena(updateCliente.getContrasena());
            cliente.setEmail(updateCliente.getEmail());
            return clienteRepository.save(cliente);
        } else {
            throw new RuntimeException("User not found with id " + id);
        }
    }

    //Finalizan los metodos
}
