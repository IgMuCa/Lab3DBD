package com.example.DEBEDE.Servicios;

import com.example.DEBEDE.Modelos.Productodeseado;
import com.example.DEBEDE.Repositorios.ProductodeseadoImplementacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/productodeseados")
public class ProductodeseadoController {
    private final ProductodeseadoImplementacion productodeseadoImplementacion;

    @Autowired
    public ProductodeseadoController(ProductodeseadoImplementacion productodeseadoImplementacion){
        this.productodeseadoImplementacion = productodeseadoImplementacion;}

    //Obtiene todos los productos deseados
    @GetMapping
    public List<Productodeseado> listarProductodeseadosImp(){
        return productodeseadoImplementacion.listarProductodeseados();
    }

    //Crea un producto deseado
    @PostMapping
    public Productodeseado crearProductodeseadoImp (@RequestBody Productodeseado productodeseado){
        return productodeseadoImplementacion.guardarProductodeseado(productodeseado);}

    //Actualiza un producto deseado
    @PutMapping("/{id}")
    public ResponseEntity<Productodeseado> updateProductodeseado(@PathVariable int id, @RequestBody Productodeseado productodeseado) {
        return ResponseEntity.ok(productodeseadoImplementacion.actualizarProdutodeseado(id, productodeseado));
    }

    //Elimina un producto deseado  por id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProductodeseadoImp(@PathVariable int id) {
       productodeseadoImplementacion.eliminarProductodeseado(id);
        return ResponseEntity.noContent().build();
    }

}
