package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Detallecarrito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class DetallecarritoImplementacion {
    private final DetallecarritoRepository detallecarritoRepository;
    @Autowired
    public DetallecarritoImplementacion(DetallecarritoRepository detallecarritoRepository){
        this.detallecarritoRepository= detallecarritoRepository;}


    //Método que lee todos los detalles de carritos
    public List<Detallecarrito> listarDetallecarrito(){
        return this.detallecarritoRepository.findAll();}


    //Método que crea y guarda un detalle de carrito
    public Detallecarrito guardarDetallecarrito (Detallecarrito detallecarrito){
        return detallecarritoRepository.save(detallecarrito);}


    //Obtener producto con mas ventas
    public List<String> listarProductosPorVenta(){
        return detallecarritoRepository.findProductoByVenta();}


    //Obtener producto con mas ventas por pyme
    public List<String> listarProductosPorVentaPorPyme(String empresa){
        return detallecarritoRepository.findProductoByVentaByPyme(empresa);}

    //Finalizan los metodos
}
