package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Boleta;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class BoletaImplementacion {
    private final BoletaRepository boletaRepository;
    @Autowired
    public BoletaImplementacion(BoletaRepository boletaRepository){
        this.boletaRepository=boletaRepository;}


    //Método que lee todos las boletas
    public List<Boleta> listarBoletas(){
        return this.boletaRepository.findAll();}


    //Método que crea y guarda una boleta
    public Boleta guardarBoleta (Boleta boleta){
        return boletaRepository.save(boleta);}

    //Finalizan los metodos
}
