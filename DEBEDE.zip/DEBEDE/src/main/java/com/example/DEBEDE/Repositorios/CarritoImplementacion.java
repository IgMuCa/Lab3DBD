package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Carrito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CarritoImplementacion {
    private final CarritoRepository carritoRepository;
    @Autowired
    public CarritoImplementacion(CarritoRepository carritoRepository){
        this.carritoRepository=carritoRepository;}

    //Método que lee todos los carritos
    public List<Carrito> listarCarritos(){
        return this.carritoRepository.findAll();}

    //Método que lee un carrito dado un id
    public void obtenerCarrito(int id) {
     carritoRepository.findById(id);}

   //Método que crea y guarda un carrito
    public Carrito guardarCarrito(Carrito carrito){
        return carritoRepository.save(carrito);}

    //Método eliminar un carrito por id
    public void eliminarCarrito(int id){
        carritoRepository.deleteById(id);}

    //Finalizan los metodos
}
