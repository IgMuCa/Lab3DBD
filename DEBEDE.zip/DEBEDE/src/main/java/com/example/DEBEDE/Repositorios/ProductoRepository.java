package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Producto;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;


public interface ProductoRepository extends JpaRepository<Producto, Integer> {

    @Query("SELECT p.precio FROM Producto p WHERE p.id = :productoid")
    Float findPrecioByProductoid(@Param("productoid") int productoid);


    @Query("SELECT p.stock FROM Producto p WHERE p.id = :productoid")
    int findStockByProductoid(@Param("productoid") int productoid);


    @Query("SELECT p " +
            "FROM Producto p " +
            "JOIN Producto_pyme pp ON p.id = pp.productoid " +
            "JOIN Pyme py ON pp.pymeid=py.id " +
            "JOIN Direccionpyme dp ON py.id=dp.pymeid " +
            "WHERE dp.ciudad = :ciudad")
    List<Producto> findProductoByCiudad(@Param("ciudad") String ciudad);


    @Query("SELECT p " +
            "FROM Producto p JOIN Categoria c ON p.categoriaid=c.id " +
            "WHERE c.categoriaprod = :categoria")
    List<Producto> findByCategoria(@Param("categoria") String categoria);





    @Modifying
    @Transactional
    @Query("DELETE FROM Producto_pyme p WHERE p.productoid = :id")
    void eraseProductopymeByProductoid(@Param("id") int id);
}
