package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Administrador;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class AdministradorImplementacion {
    private final AdministradorRepository administradorRepository;
    @Autowired
    public AdministradorImplementacion(AdministradorRepository administradorRepository){
        this.administradorRepository=administradorRepository;}

    //Método que lee todos los administradores
    public List<Administrador> listarAdministradores(){
        return this.administradorRepository.findAll();}

    //Método que lee un administrador dado un id
    public void obtenerAdministrador(int id) {
        administradorRepository.findById(id);}

   //Método que crea y guarda un administrador
    public Administrador guardarAdministrador (Administrador administrador){
        return administradorRepository.save(administrador);}

    //Método eliminar un administrador por id
    public void eliminarAdministrador(int id){
        administradorRepository.deleteById(id);}

    //Metodo para actualizar un administrador
    public Administrador actualizarAdministrador(int id, Administrador updateAdministrador) {
        Optional<Administrador> administradorOptional = administradorRepository.findById(id);
        if (administradorOptional.isPresent()) {
            Administrador administrador = administradorOptional.get();
            administrador.setNombre(updateAdministrador.getNombre());
            administrador.setApellido(updateAdministrador.getApellido());
            administrador.setContrasena(updateAdministrador.getContrasena());
            administrador.setEmail(updateAdministrador.getEmail());
            return administradorRepository.save(administrador);
        } else {
            throw new RuntimeException("User not found with id " + id);
        }
    }

    //Finalizan los metodos
}
