package com.example.DEBEDE.Servicios;

import com.example.DEBEDE.Modelos.Carrito;
import com.example.DEBEDE.Repositorios.CarritoImplementacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/carritos")
public class CarritoController {
    private final CarritoImplementacion carritoImplementacion;

    @Autowired
    public CarritoController(CarritoImplementacion carritoImplementacion){
        this.carritoImplementacion=carritoImplementacion;}

    //Obtiene todos los carritoe
    @GetMapping
    public List<Carrito> listarCarritoImp(){
        return carritoImplementacion.listarCarritos();
    }

    //Crea un carrito
    @PostMapping
    public Carrito crearCarritoImp (@RequestBody Carrito carrito){
        return carritoImplementacion.guardarCarrito(carrito);}

    //Elimina un cliente por id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCarritoImp(@PathVariable int id) {
        carritoImplementacion.eliminarCarrito(id);
        return ResponseEntity.noContent().build();
    }

}
