package com.example.DEBEDE.Servicios;

import com.example.DEBEDE.Modelos.Boleta;
import com.example.DEBEDE.Repositorios.DetallecarritoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoletaService {
    @Autowired
    private final DetallecarritoRepository detallecarritoRepository;

    public BoletaService(DetallecarritoRepository detallecarritoRepository) {
        this.detallecarritoRepository=detallecarritoRepository;
    }

    public Boleta calcularTotal(Boleta boleta) {
        int carritoid = boleta.getCarritoid();
       // String pago = "no_pagado";

        // Obtener el total parcial del carrito
        Float total = detallecarritoRepository.findTotalByCarritoid(carritoid);

        // Manejar el caso en que el total sea nulo
        if (total == null) {
            total = 0.0f;
        }

        // Establecer el total en la boleta
        boleta.setTotal(total.doubleValue());

        return boleta;
    }

}
