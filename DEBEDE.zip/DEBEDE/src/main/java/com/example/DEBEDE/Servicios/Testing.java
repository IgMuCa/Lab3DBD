package com.example.DEBEDE.Servicios;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Testing {
    @GetMapping("/hello")
    public String HelloWord(){
        return "Hola";
    }


}
