package com.example.DEBEDE.Repositorios;

import com.example.DEBEDE.Modelos.Valoracionusuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class ValoracionusuarioImplementacion {
    private final ValoracionusuarioRepository valoracionusuarioRepository;
    @Autowired
    public ValoracionusuarioImplementacion(ValoracionusuarioRepository valoracionusuarioRepository){
        this.valoracionusuarioRepository=valoracionusuarioRepository;}

    //Método que lee todos las valoraciones
    public List<Valoracionusuario> listarValoracionusuario(){
        return this.valoracionusuarioRepository.findAll();}

    //Método que lee una valoracion dado un id
    public void obtenerValoracionusuario(int id) {
        valoracionusuarioRepository.findById(id);}

   //Método que crea y guarda un administrador
    public Valoracionusuario guardarValoracionusuario (Valoracionusuario valoracionusuario){
        return valoracionusuarioRepository.save(valoracionusuario);}

    //Método eliminar una valoracion por id
    public void eliminarValoracionusuario(int id){
        valoracionusuarioRepository.deleteById(id);}

    //Metodo para actualizar un administrador
    public Valoracionusuario actualizarValoracionusuario(int id, Valoracionusuario updateValoracionusuario) {
        Optional<Valoracionusuario> valoracionusuarioOptional = valoracionusuarioRepository.findById(id);
        if (valoracionusuarioOptional.isPresent()) {
            Valoracionusuario valoracionusuario = valoracionusuarioOptional.get();
            valoracionusuario.setClienteid(updateValoracionusuario.getClienteid());
            valoracionusuario.setProductoid(updateValoracionusuario.getProductoid());
            valoracionusuario.setValoracion(updateValoracionusuario.getValoracion());
            return valoracionusuarioRepository.save(valoracionusuario);
        } else {
            throw new RuntimeException("User not found with id " + id);
        }
    }

    //Finalizan los metodos
}
